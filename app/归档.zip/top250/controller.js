(function (angular) {
	'use strict';
//创建正在热映的模块
var module = angular.module('moviecat.top250', ['ngRoute'])
//配置模块的路由  总路由里面只配置了一个otherwise  然后配置了自身的路由 好处？模块自己管理自己 更方便
module.config(['$routeProvider', function($routeProvider) {
	// 当我们的路径是/in_theaters 的时候 他就会去找下面的view.html 和InTheaterController控制器
	// 接着去处理控制起的逻辑
  $routeProvider.when('/top250', {
    templateUrl: 'top250/view.html', 
    controller: 'TopController'
  });
}])

module.controller('TopController', [
	'$scope'
	,function($scope) {
  
}]);
})(angular) 